
import { GoogleGenAI, Type } from "@google/genai";
import { Booking } from "../types";

export class LabAIService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async analyzeSchedule(bookings: Booking[], query: string): Promise<string> {
    const context = JSON.stringify(bookings.map(b => ({
      guru: b.teacherName,
      lab: b.labName,
      waktu: `${b.date} ${b.startTime}-${b.endTime}`,
      tujuan: b.purpose
    })));

    const response = await this.ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `
        Anda adalah asisten admin Lab Komputer sekolah yang cerdas. 
        Berikut adalah data jadwal booking saat ini: ${context}
        
        Pertanyaan user: ${query}
        
        Berikan jawaban yang ringkas, membantu, dan dalam Bahasa Indonesia yang ramah. 
        Jika ada konflik jadwal, berikan saran solusi.
      `,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });

    return response.text || "Maaf, saya tidak dapat memproses permintaan Anda saat ini.";
  }

  async getSchedulingAdvice(bookings: Booking[]): Promise<string> {
    const context = JSON.stringify(bookings);
    const response = await this.ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analisis jadwal penggunaan lab ini dan berikan 3 poin ringkas untuk optimasi penggunaan lab besok. Data: ${context}. Gunakan Bahasa Indonesia.`,
    });
    return response.text || "";
  }
}

export const labAI = new LabAIService();
