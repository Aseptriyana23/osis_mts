
import React, { useState, useEffect, useCallback } from 'react';
import { Booking, LabType, BookingStatus } from './types';
import { NAVIGATION_ITEMS, APP_NAME } from './constants';
import BookingForm from './components/BookingForm';
import BookingList from './components/BookingList';
import AIChatPanel from './components/AIChatPanel';
import { Monitor, Bell, Search, Menu, X, CheckSquare, Clock } from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [bookings, setBookings] = useState<Booking[]>(() => {
    const saved = localStorage.getItem('lab_bookings');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('lab_bookings', JSON.stringify(bookings));
  }, [bookings]);

  const addBooking = useCallback((newBooking: Booking) => {
    setBookings(prev => [newBooking, ...prev]);
  }, []);

  const deleteBooking = useCallback((id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus jadwal ini?')) {
      setBookings(prev => prev.filter(b => b.id !== id));
    }
  }, []);

  const updateStatus = useCallback((id: string, status: BookingStatus) => {
    setBookings(prev => prev.map(b => b.id === id ? { ...b, status } : b));
  }, []);

  const todayBookings = bookings.filter(b => b.date === new Date().toISOString().split('T')[0]);

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-72 bg-white border-r border-slate-200 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform duration-300 ease-in-out`}>
        <div className="p-6 h-full flex flex-col">
          <div className="flex items-center gap-3 mb-10">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
              <Monitor size={24} />
            </div>
            <span className="text-xl font-bold tracking-tight">{APP_NAME}</span>
          </div>

          <nav className="flex-1 space-y-1">
            {NAVIGATION_ITEMS.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                  activeTab === item.id 
                  ? 'bg-indigo-50 text-indigo-700 font-semibold' 
                  : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </nav>

          <div className="mt-auto pt-6 border-t border-slate-100">
            <div className="bg-slate-50 rounded-2xl p-4">
              <p className="text-xs font-medium text-slate-400 mb-2">STATUS SERVER</p>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm font-semibold text-slate-700">Online & Sinkron</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-w-0 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="h-20 bg-white border-b border-slate-200 px-6 flex items-center justify-between sticky top-0 z-30">
          <button 
            className="lg:hidden p-2 hover:bg-slate-100 rounded-lg"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu size={24} />
          </button>

          <div className="flex-1 max-w-xl mx-4 hidden md:block">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
              <input 
                type="text" 
                placeholder="Cari guru atau jadwal..."
                className="w-full bg-slate-50 border-none rounded-xl pl-10 pr-4 py-2.5 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2.5 text-slate-500 hover:bg-slate-50 rounded-xl relative">
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="h-8 w-px bg-slate-200 mx-2"></div>
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-bold text-slate-900 leading-none">Admin Lab</p>
                <p className="text-xs text-slate-500 mt-1">Staf IT</p>
              </div>
              <img 
                src="https://picsum.photos/seed/admin/40/40" 
                alt="Avatar" 
                className="w-10 h-10 rounded-xl border border-slate-200"
              />
            </div>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-8">
          {activeTab === 'dashboard' && (
            <div className="max-w-7xl mx-auto space-y-8">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h1 className="text-3xl font-extrabold text-slate-900">Dashboard Utama</h1>
                  <p className="text-slate-500 mt-1">Ringkasan penggunaan laboratorium hari ini.</p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setActiveTab('booking')}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-semibold hover:bg-indigo-700 transition-colors"
                  >
                    + Tambah Booking
                  </button>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-4">
                  <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center">
                    <CheckSquare size={28} />
                  </div>
                  <div>
                    <p className="text-sm text-slate-500 font-medium uppercase tracking-wider">Booking Hari Ini</p>
                    <p className="text-2xl font-black text-slate-900">{todayBookings.length}</p>
                  </div>
                </div>
                <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-4">
                  <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
                    <Clock size={28} />
                  </div>
                  <div>
                    <p className="text-sm text-slate-500 font-medium uppercase tracking-wider">Total Penjadwalan</p>
                    <p className="text-2xl font-black text-slate-900">{bookings.length}</p>
                  </div>
                </div>
                <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-4">
                  <div className="w-14 h-14 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center">
                    <Monitor size={28} />
                  </div>
                  <div>
                    <p className="text-sm text-slate-500 font-medium uppercase tracking-wider">Lab Tersedia</p>
                    <p className="text-2xl font-black text-slate-900">3 Ruangan</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                  <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6">
                    <BookingList 
                      bookings={todayBookings} 
                      onDelete={deleteBooking}
                      onUpdateStatus={updateStatus}
                    />
                  </div>
                </div>
                <div className="space-y-8">
                  <AIChatPanel bookings={bookings} />
                  <div className="bg-indigo-600 rounded-3xl p-6 text-white shadow-xl shadow-indigo-100 relative overflow-hidden">
                    <div className="relative z-10">
                      <h4 className="font-bold text-lg mb-2">Tips Optimasi Lab</h4>
                      <p className="text-indigo-100 text-sm leading-relaxed mb-4">
                        Gunakan fitur pembersihan otomatis setelah praktikum pemrograman selesai untuk menjaga kinerja unit komputer.
                      </p>
                      <button className="text-sm font-bold bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg transition-colors">
                        Pelajari Selengkapnya
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'booking' && (
            <div className="max-w-4xl mx-auto">
              <div className="mb-8">
                <h1 className="text-3xl font-extrabold text-slate-900">Buat Jadwal Baru</h1>
                <p className="text-slate-500 mt-1">Isi formulir untuk meminjam fasilitas laboratorium komputer.</p>
              </div>
              <BookingForm onAddBooking={addBooking} />
            </div>
          )}

          {activeTab === 'history' && (
            <div className="max-w-7xl mx-auto">
              <div className="mb-8">
                <h1 className="text-3xl font-extrabold text-slate-900">Seluruh Jadwal & Riwayat</h1>
                <p className="text-slate-500 mt-1">Daftar lengkap pendaftaran dari semua laboratorium.</p>
              </div>
              <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6">
                <BookingList 
                  bookings={bookings} 
                  onDelete={deleteBooking}
                  onUpdateStatus={updateStatus}
                />
              </div>
            </div>
          )}

          {activeTab === 'teachers' && (
            <div className="max-w-7xl mx-auto">
               <div className="mb-8">
                <h1 className="text-3xl font-extrabold text-slate-900">Daftar Guru Terdaftar</h1>
                <p className="text-slate-500 mt-1">Informasi guru yang sering menggunakan fasilitas lab.</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array.from(new Set(bookings.map(b => b.teacherName))).map((teacher, idx) => (
                  <div key={idx} className="bg-white p-6 rounded-3xl border border-slate-200 flex items-center gap-4 hover:border-indigo-300 transition-all cursor-default">
                    <img src={`https://picsum.photos/seed/${teacher}/48/48`} className="w-12 h-12 rounded-full" alt={teacher} />
                    <div>
                      <h4 className="font-bold text-slate-900">{teacher}</h4>
                      <p className="text-xs text-slate-500">{bookings.filter(b => b.teacherName === teacher).length} Total Booking</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
