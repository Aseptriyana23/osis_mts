
export enum LabType {
  LAB_A = 'Lab Komputer A',
  LAB_B = 'Lab Komputer B',
  LAB_C = 'Lab Multimedia'
}

export enum BookingStatus {
  PENDING = 'Menunggu',
  CONFIRMED = 'Dikonfirmasi',
  CANCELLED = 'Dibatalkan',
  COMPLETED = 'Selesai'
}

export interface Booking {
  id: string;
  teacherName: string;
  labName: LabType;
  date: string;
  startTime: string;
  endTime: string;
  purpose: string;
  status: BookingStatus;
  createdAt: number;
}

export interface LabStats {
  totalBookings: number;
  mostActiveLab: string;
  activeTeachers: number;
}
