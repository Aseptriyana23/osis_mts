
import React, { useState } from 'react';
import { LabType, BookingStatus, Booking } from '../types';
import { Calendar, Clock, User, MessageSquare, Save } from 'lucide-react';

interface BookingFormProps {
  onAddBooking: (booking: Booking) => void;
}

const BookingForm: React.FC<BookingFormProps> = ({ onAddBooking }) => {
  const [formData, setFormData] = useState({
    teacherName: '',
    labName: LabType.LAB_A,
    date: new Date().toISOString().split('T')[0],
    startTime: '07:30',
    endTime: '09:00',
    purpose: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.teacherName || !formData.purpose) return;

    const newBooking: Booking = {
      id: Math.random().toString(36).substr(2, 9),
      ...formData,
      status: BookingStatus.CONFIRMED,
      createdAt: Date.now()
    };

    onAddBooking(newBooking);
    setFormData({
      ...formData,
      teacherName: '',
      purpose: ''
    });
    alert('Booking berhasil ditambahkan!');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-6">
      <div className="flex items-center gap-2 mb-2">
        <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
          <Calendar size={20} />
        </div>
        <h2 className="text-xl font-bold text-slate-800">Form Peminjaman Lab</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
            <User size={16} /> Nama Guru
          </label>
          <input
            type="text"
            required
            className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
            placeholder="Contoh: Bpk. Budi"
            value={formData.teacherName}
            onChange={e => setFormData({...formData, teacherName: e.target.value})}
          />
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
            <Calendar size={16} /> Pilih Laboratorium
          </label>
          <select
            className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
            value={formData.labName}
            onChange={e => setFormData({...formData, labName: e.target.value as LabType})}
          >
            {Object.values(LabType).map(lab => (
              <option key={lab} value={lab}>{lab}</option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
            <Calendar size={16} /> Tanggal Peminjaman
          </label>
          <input
            type="date"
            required
            className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
            value={formData.date}
            onChange={e => setFormData({...formData, date: e.target.value})}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
              <Clock size={16} /> Jam Mulai
            </label>
            <input
              type="time"
              required
              className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
              value={formData.startTime}
              onChange={e => setFormData({...formData, startTime: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
              <Clock size={16} /> Jam Selesai
            </label>
            <input
              type="time"
              required
              className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
              value={formData.endTime}
              onChange={e => setFormData({...formData, endTime: e.target.value})}
            />
          </div>
        </div>

        <div className="md:col-span-2 space-y-2">
          <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
            <MessageSquare size={16} /> Keperluan / Mata Pelajaran
          </label>
          <textarea
            required
            rows={3}
            className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
            placeholder="Contoh: Praktikum Pemrograman Web Kelas XI RPL"
            value={formData.purpose}
            onChange={e => setFormData({...formData, purpose: e.target.value})}
          />
        </div>
      </div>

      <button
        type="submit"
        className="w-full md:w-auto px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-indigo-200 active:scale-95"
      >
        <Save size={20} />
        Simpan Jadwal
      </button>
    </form>
  );
};

export default BookingForm;
