
import React, { useState } from 'react';
import { labAI } from '../services/geminiService';
import { Booking } from '../types';
import { Send, Bot, Sparkles, Loader2 } from 'lucide-react';

interface AIChatPanelProps {
  bookings: Booking[];
}

const AIChatPanel: React.FC<AIChatPanelProps> = ({ bookings }) => {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    try {
      const result = await labAI.analyzeSchedule(bookings, query);
      setResponse(result);
    } catch (err) {
      setResponse("Terjadi kesalahan saat menghubungi AI.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-900 rounded-3xl shadow-2xl p-6 text-white overflow-hidden relative group">
      <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
        <Sparkles size={120} />
      </div>

      <div className="relative z-10 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center animate-pulse">
            <Bot size={24} />
          </div>
          <div>
            <h3 className="font-bold text-lg">Asisten Lab AI</h3>
            <p className="text-slate-400 text-xs">Cek ketersediaan & optimasi jadwal</p>
          </div>
        </div>

        <div className="min-h-[100px] bg-slate-800/50 rounded-2xl p-4 text-sm leading-relaxed border border-slate-700">
          {loading ? (
            <div className="flex items-center justify-center h-full gap-2 text-indigo-400">
              <Loader2 className="animate-spin" size={20} />
              <span>Sedang berpikir...</span>
            </div>
          ) : response ? (
            <div className="prose prose-invert prose-sm">
              {response}
            </div>
          ) : (
            <p className="text-slate-500 italic">
              "Siapa saja yang pakai Lab A besok?" atau "Tolong rekomendasikan waktu kosong untuk Lab Multimedia minggu depan."
            </p>
          )}
        </div>

        <form onSubmit={handleAsk} className="flex gap-2">
          <input
            type="text"
            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder="Tanya asisten AI..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <button
            type="submit"
            disabled={loading}
            className="bg-indigo-600 p-2 rounded-xl hover:bg-indigo-700 transition-colors disabled:opacity-50"
          >
            <Send size={20} />
          </button>
        </form>
      </div>
    </div>
  );
};

export default AIChatPanel;
