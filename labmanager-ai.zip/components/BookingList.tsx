
import React, { useState } from 'react';
import { Booking, BookingStatus, LabType } from '../types';
import { Clock, Calendar, User, Trash2, CheckCircle, XCircle } from 'lucide-react';

interface BookingListProps {
  bookings: Booking[];
  onDelete: (id: string) => void;
  onUpdateStatus: (id: string, status: BookingStatus) => void;
}

const BookingList: React.FC<BookingListProps> = ({ bookings, onDelete, onUpdateStatus }) => {
  const [filter, setFilter] = useState<string>('all');

  const filteredBookings = bookings
    .filter(b => filter === 'all' || b.labName === filter)
    .sort((a, b) => b.createdAt - a.createdAt);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold text-slate-800">Daftar Jadwal</h3>
        <select 
          className="px-3 py-1.5 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          <option value="all">Semua Lab</option>
          {Object.values(LabType).map(lab => (
            <option key={lab} value={lab}>{lab}</option>
          ))}
        </select>
      </div>

      <div className="grid gap-4">
        {filteredBookings.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-300 text-slate-400">
            Belum ada jadwal pendaftaran.
          </div>
        ) : (
          filteredBookings.map(booking => (
            <div key={booking.id} className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:shadow-md transition-shadow">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                    booking.labName === LabType.LAB_A ? 'bg-blue-100 text-blue-700' : 
                    booking.labName === LabType.LAB_B ? 'bg-purple-100 text-purple-700' : 'bg-emerald-100 text-emerald-700'
                  }`}>
                    {booking.labName}
                  </span>
                  <span className="text-xs text-slate-400">•</span>
                  <span className="flex items-center gap-1 text-xs text-slate-500">
                    <Calendar size={12} /> {booking.date}
                  </span>
                </div>
                <h4 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                   {booking.teacherName}
                </h4>
                <p className="text-sm text-slate-600 line-clamp-1">{booking.purpose}</p>
                <div className="flex items-center gap-4 text-slate-500 text-sm">
                  <span className="flex items-center gap-1.5">
                    <Clock size={14} className="text-indigo-500" />
                    {booking.startTime} - {booking.endTime}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 border-t md:border-t-0 pt-4 md:pt-0">
                <button 
                  onClick={() => onDelete(booking.id)}
                  className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  title="Hapus"
                >
                  <Trash2 size={20} />
                </button>
                <div className="h-6 w-px bg-slate-200 mx-1 hidden md:block"></div>
                <button 
                  onClick={() => onUpdateStatus(booking.id, BookingStatus.CANCELLED)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Batalkan
                </button>
                <span className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                  booking.status === BookingStatus.CONFIRMED ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'
                }`}>
                  {booking.status}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default BookingList;
