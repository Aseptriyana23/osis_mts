
import React from 'react';
import { 
  LayoutDashboard, 
  CalendarPlus, 
  History, 
  Users, 
  Monitor,
  Settings,
  AlertCircle
} from 'lucide-react';

export const APP_NAME = "LabManager AI";

export const NAVIGATION_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
  { id: 'booking', label: 'Booking Baru', icon: <CalendarPlus size={20} /> },
  { id: 'history', label: 'Riwayat & Jadwal', icon: <History size={20} /> },
  { id: 'teachers', label: 'Daftar Guru', icon: <Users size={20} /> },
];

export const LAB_COLORS = {
  'Lab Komputer A': 'bg-blue-100 text-blue-700 border-blue-200',
  'Lab Komputer B': 'bg-purple-100 text-purple-700 border-purple-200',
  'Lab Komputer C': 'bg-emerald-100 text-emerald-700 border-emerald-200',
};
